from collections import OrderedDict
import os
import torch
import numpy as np
import json

from ultralytics import YOLO


def rand_normalize_directions(conf_file, states, ignore='biasbn'):
    # assert(len(direction) == len(states))

    init_dict = YOLO(conf_file).model.state_dict()
    new_dict = OrderedDict()
    for (k, w), (k2, d) in zip(states.items(), init_dict.items()):
        w = torch.tensor(w, dtype=torch.float32)
        d = torch.nn.init.normal_(torch.tensor(d, dtype=torch.float32))
        if w.dim() <= 1:
            if ignore == 'biasbn':
                d = torch.zeros_like(w)  # ignore directions for weights with 1 dimension
            else:
                d = w
        else:
        # if w.dim() > 1:
            d.mul_(w.norm()/(d.norm() + 1e-10))
        new_dict[k] = d
    return new_dict


def get_combined_weights(direction1, direction2, pretrained, weight1, weight2, weight_pretrained=1.0):
    new_dict = OrderedDict()
    for (k, d1),(_,d2), (_,w) in zip(direction1.items(), direction2.items(), pretrained.items()):
        wd1 = weight1 * d1
        # print(wd1.shape)
        wd2 = weight2 * d2
        # print(wd2.shape)
        ww = weight_pretrained * w
        # print(ww.shape)
        new_dict[k] = (wd1+wd2+ww)
        # new_dict[k] = (weight1 * d1 + weight2 * d2 + weight_pretrained * w)/\
        #               (abs(weight1)+abs(weight2)+abs(weight_pretrained))
    return new_dict


if __name__ == '__main__':

    model_conf = "best.pt"
    sd = YOLO('best.pt').model.state_dict()  # load pretrained

    # net = YOLO(model_conf)
    # net.model.load_state_dict(sd)

    direction1 = rand_normalize_directions(model_conf, sd, ignore='')
    direction2 = rand_normalize_directions(model_conf, sd, ignore='')

    # list_1 = np.arange(-1, 1.1, 0.1)
    # list_2 = np.arange(-1, 1.1, 0.1)
    list_1 = [0, 0.1]
    list_2 = [0, 0.1]

    loss_dict = {}
    weights_list = []

    for w1 in list_1:
        for w2 in list_2:
            print("\n\n===> w1 {w1:.3f} w2 {w2:.3f}".format(w1=w1, w2=w2))
            combined_weights = get_combined_weights(direction1, direction2, sd, w1, w2)

            torch.save(combined_weights, 'temp/new_weights.wts')

            weights_list.append(combined_weights)
            net = YOLO(model_conf)
            net.model.load_state_dict(combined_weights)
            # net.train(data='E:\\WorkSpace\\PySpace\\ultralytics\\ultralytics\\datasets\\det-fly_val.yaml', optimizer='Adam', imgsz=320, val=True, epochs=1, lr0=0, lrf=1, weight_decay=0, seed=8)
            net.val(data='E:\\WorkSpace\\PySpace\\ultralytics\\ultralytics\\datasets\\det-fly_val.yaml', imgsz=1280)
            loss_dict[len(os.listdir('losses'))] = {
                'w1': w1,
                'w2': w2
            }
            del net.model
            del net

    with open('losses/loss_table.json', 'w') as lt:
        lt.write(str(loss_dict))






