import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import numpy as np

import os
import json
import demjson  # it needs to downgrade setuptools: pip install setuptools~=57.5.0


with open('losses/loss_table.json', 'r') as f:
    lt_str = f.read()
    lt = demjson.decode(lt_str)

Wx = []  # x axis
Wy = []  # y axis
Lz0, Lz1, Lz2 = [], [], []   # 3 losses

for filename, coords in lt.items():
    with open('losses/{:04d}.txt'.format(filename), 'r') as l:
        loss_list = l.read().replace('[', '').replace(']', '').replace(' ', '').split(',')
        loss_list = [float(i) for i in loss_list]
        w1 = round(coords['w1']*10)/10
        w2 = round(coords['w2']*10)/10
        Wx.append(w1)
        Wy.append(w2)
        Lz0.append(loss_list[0])
        Lz1.append(loss_list[1])
        Lz2.append(loss_list[2])


Lz0, Lz1, Lz2 = np.array(Lz0), np.array(Lz1), np.array(Lz2)

# normalize
Lz0 = (Lz0-Lz0.min())/(Lz0.max()-Lz0.min())
Lz1 = (Lz1-Lz1.min())/(Lz1.max()-Lz1.min())
Lz2 = (Lz2-Lz2.min())/(Lz2.max()-Lz2.min())

Lz = Lz1 + Lz0 + Lz2

Wx, Wy, Lz = np.array(Wx), np.array(Wy), np.array(Lz)   # normal plot
# Wx, Wy, Lz = np.array(Wx), np.array(Wy), np.array(np.log10(np.array(Lz)))  # log plot

# Lz[Lz > 1000] = 1000  # clip to 1000


# plt.rcParams["font.family"] = "serif"
fig = plt.figure()
ax = fig.add_subplot(projection='3d')

Wx = np.arange(-1, 1.1, 0.1)
Wy = np.arange(-1, 1.1, 0.1)
Wx, Wy = np.meshgrid(Wx, Wy)
Lz = Lz.reshape((21, 21))

surf = ax.plot_surface(Wx, Wy, Lz, rstride=1, cstride=1, cmap=cm.coolwarm,
                       linewidth=0, antialiased=False)

# ax.set_xlabel()
# ax.set_ylabel()
ax.set_zlabel('Loss ($log_{10}x$)')
plt.show()

# for angle in range(0, 360*4 + 1):
#     # Normalize the angle to the range [-180, 180] for display
#     angle_norm = (angle + 180) % 360 - 180
#
#     # Cycle through a full rotation of elevation, then azimuth, roll, and all
#     elev = azim = roll = 0
#     if angle <= 360:
#         elev = angle_norm
#     elif angle <= 360*2:
#         azim = angle_norm
#     elif angle <= 360*3:
#         roll = angle_norm
#     else:
#         elev = azim = roll = angle_norm
#
#     # Update the axis view and title
#     ax.view_init(elev, azim, roll)
#     plt.title('Elevation: %d°, Azimuth: %d°, Roll: %d°' % (elev, azim, roll))
#
#     plt.draw()
#     plt.pause(.001)




